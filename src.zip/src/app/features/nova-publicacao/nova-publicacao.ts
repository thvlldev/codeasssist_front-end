import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { forkJoin, switchMap, of } from 'rxjs';
import { PublicacaoService } from '../../services/publicacao.service';
import { PublicacaoTecnologiaService } from '../../services/publicacao_tecnologia.service';
import { TecnologiaService } from '../../services/tecnologia.service';
import { AuthService } from '../../services/auth.service';
import { Tecnologia } from '../../model/tecnologia.model';

@Component({
  selector: 'app-nova-publicacao',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './nova-publicacao.html',
  styleUrls: ['./nova-publicacao.css']
})
export class NovaPublicacaoComponent implements OnInit {

  private publicacaoService = inject(PublicacaoService);
  private publicacaoTecnologiaService = inject(PublicacaoTecnologiaService);
  private tecnologiaService = inject(TecnologiaService);
  private authService = inject(AuthService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);

  tecnologiasDisponiveis: Tecnologia[] = [];
  ehMentor: boolean = false; // Flag para o HTML bloquear a tela

  novaPublicacao = {
    titulo: '',
    conteudo: '',
    orcamentoMin: 0,
    orcamentoMax: 0,
    usuarioId: this.authService.getUsuarioId() ?? 0,
    status: 1
  };

  tecnologiasIds: number[] = [];

  ngOnInit(): void {
    // Pega o papel ativo diretamente do seu authService usando a diferenciação que já existe
    const papelAtivo = this.authService.getPapelAtivo();

    // Identifica se é mentor (Seja se o seu retorno for string "Mentor", ou o número 1)
    this.ehMentor = papelAtivo === 1;

    if (!this.ehMentor) {
      this.tecnologiaService.listarTodas().subscribe({
        next: (techs) => {
          this.tecnologiasDisponiveis = techs || [];
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Erro ao carregar tecnologias:', err);
          this.cdr.detectChanges();
        }
      });
    }
  }

  toggleTecnologia(techId: number): void {
    const index = this.tecnologiasIds.indexOf(techId);
    if (index >= 0) {
      this.tecnologiasIds.splice(index, 1);
    } else if (this.tecnologiasIds.length < 5) {
      this.tecnologiasIds.push(techId);
    }
    this.cdr.detectChanges();
  }

  salvarPublicacao(): void {
    if (this.ehMentor) return;

    if (!this.novaPublicacao.titulo?.trim() ||
        !this.novaPublicacao.conteudo?.trim() ||
        this.tecnologiasIds.length === 0) {
      return;
    }

    this.publicacaoService.criar(this.novaPublicacao).pipe(
      switchMap((publicacaoCriada) => {
        if (this.tecnologiasIds.length === 0) return of([]);

        const requests = this.tecnologiasIds.map(techId =>
          this.publicacaoTecnologiaService.criar({
            publicacaoId: publicacaoCriada.id,
            tecnologiaId: techId,
            status: 1
          })
        );
        return forkJoin(requests);
      })
    ).subscribe({
      next: () => {
        this.router.navigate(['/app/publicacoes']);
      },
      error: (err) => {
        console.error('Erro ao salvar publicação:', err);
        this.router.navigate(['/app/publicacoes']);
      }
    });
  }
}